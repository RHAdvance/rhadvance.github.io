
<!--
function openlist(){
	subWin = window.open("./taioukisyu/index.html","subWin","width=600,height=550,scrollbars=0");subWin.focus(); 
	}
function openkouryak(){
	subWin = window.open("./kouryak/index.html","subWin","width=600,height=500,scrollbars=0");subWin.focus(); 
	}
function opentopics01(){
	topicsWin = window.open("./topics/index.html","topicsWin","width=660,height=530,scrollbars=1");topicsWin.focus(); 
	}
function opentopics02(){
	topicsWin = window.open("./topics/index.html#topics02","topicsWin","width=660,height=530,scrollbars=1");topicsWin.focus(); 
	}
function opentopics03(){
	topicsWin = window.open("./topics/index.html#topics03","topicsWin","width=660,height=740,scrollbars=1");topicsWin.focus(); 
	}
function opentopics04(){
	topicsWin = window.open("./topics/index.html#topics04","topicsWin","width=660,height=530,scrollbars=1");topicsWin.focus(); 
	}
function opentopics05(){
	topicsWin = window.open("./topics/index.html#topics05","topicsWin","width=660,height=530,scrollbars=1");topicsWin.focus(); 
	}
//-->

<!--
function opensta01_1(){
	sta01 = window.open("./stage01_1.html","sta01","width=600,height=370,scrollbars=0");sta01.focus(); 
	}
function opensta01_2(){
	sta01 = window.open("./stage01_2.html","sta01","width=600,height=370,scrollbars=0");sta01.focus(); 
	}
function opensta01_3(){
	sta01 = window.open("./stage01_3.html","sta01","width=600,height=370,scrollbars=0");sta01.focus(); 
	}
function opensta01_4(){
	sta01 = window.open("./stage01_4.html","sta01","width=600,height=370,scrollbars=0");sta01.focus(); 
	}
function opensta01_5(){
	sta01 = window.open("./stage01_5.html","sta01","width=600,height=370,scrollbars=0");sta01.focus(); 
	}
//-->

<!--
function openchart(){
	omakewin = window.open("./diagnosis/index.html","omakewin","width=600,height=520,scrollbars=0");omakewin.focus(); 
	}
//-->

<!--
function opentm01(){
	tmWin = window.open("./tm_01.html","tmWin","width=480,height=520,scrollbars=0");tmWin.focus(); 
	}
function opentm02(){
	tmWin = window.open("./tm_02.html","tmWin","width=480,height=520,scrollbars=0");tmWin.focus(); 
	}
function opentm03(){
	tmWin = window.open("./tm_03.html","tmWin","width=480,height=520,scrollbars=0");tmWin.focus(); 
	}
function opentm04(){
	tmWin = window.open("./tm_04.html","tmWin","width=480,height=520,scrollbars=0");tmWin.focus(); 
	}
function opentm05(){
	tmWin = window.open("./tm_05.html","tmWin","width=480,height=520,scrollbars=0");tmWin.focus(); 
	}
function opentm06(){
	tmWin = window.open("./tm_06.html","tmWin","width=480,height=520,scrollbars=0");tmWin.focus(); 
	}
function opentm07(){
	tmWin = window.open("./tm_07.html","tmWin","width=490,height=520,scrollbars=0");tmWin.focus(); 
	}
//-->
